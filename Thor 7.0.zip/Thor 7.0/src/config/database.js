module.exports = {
    'url': 'mongodb://localhost/thor-users'
};